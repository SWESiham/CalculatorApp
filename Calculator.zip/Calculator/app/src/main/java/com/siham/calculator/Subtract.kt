package com.siham.calculator

class Subtract {
    fun perform(x:Double,y:Double):Double{
        return x-y
    }
}