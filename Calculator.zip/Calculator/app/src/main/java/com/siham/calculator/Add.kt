package com.siham.calculator

class Add {
    fun perform(x:Double, y:Double):Double{

        return x+y
    }


}