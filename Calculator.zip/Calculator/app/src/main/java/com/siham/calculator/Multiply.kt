package com.siham.calculator

class Multiply {
    fun perform(x:Double,y:Double):Double{
        return x*y
    }
}