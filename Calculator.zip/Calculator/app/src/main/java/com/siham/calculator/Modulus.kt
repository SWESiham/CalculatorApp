package com.siham.calculator

class Modulus {
    fun perform(x:Double, y:Double):Double{

        return x%y
    }
}